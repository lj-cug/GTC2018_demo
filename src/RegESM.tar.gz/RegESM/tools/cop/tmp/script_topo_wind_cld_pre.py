
from paraview.simple import *
from paraview import coprocessing


#--------------------------------------------------------------
# Code generated from cpstate.py to create the CoProcessor.
# ParaView 5.2.0-RC3 64 bits


# ----------------------- CoProcessor definition -----------------------

def CreateCoProcessor():
  def _CreatePipeline(coprocessor, datadescription):
    class Pipeline:
      # state file generated using paraview version 5.2.0-RC3

      # ----------------------------------------------------------------
      # setup views used in the visualization
      # ----------------------------------------------------------------

      #### disable automatic camera reset on 'Show'
      paraview.simple._DisableFirstRenderCameraReset()

      # Create a new 'Render View'
      renderView1 = CreateView('RenderView')
      renderView1.ViewSize = [1158, 756]
      renderView1.AxesGrid = 'GridAxes3DActor'
      renderView1.CenterOfRotation = [34.5676107406616, 41.595760345459, 1.002]
      renderView1.StereoType = 0
      renderView1.CameraPosition = [11.2082905163635, 24.3137378727242, 20.0634213166368]
      renderView1.CameraFocalPoint = [34.6598585943156, 41.6640084564748, 0.926724898362781]
      renderView1.CameraViewUp = [0.24083121697952303, 0.5536910285919341, 0.7971364812784371]
      renderView1.CameraParallelScale = 1.73205080756888
      renderView1.Background = [0.32, 0.34, 0.43]

      # init the 'GridAxes3DActor' selected for 'AxesGrid'
      renderView1.AxesGrid.Visibility = 1
      renderView1.AxesGrid.XTitle = 'Longitude'
      renderView1.AxesGrid.YTitle = 'Latitude'
      renderView1.AxesGrid.ZTitle = 'Height (m)'
      renderView1.AxesGrid.XTitleBold = 1
      renderView1.AxesGrid.YTitleBold = 1
      renderView1.AxesGrid.ZTitleBold = 1
      renderView1.AxesGrid.XLabelBold = 1
      renderView1.AxesGrid.YLabelBold = 1
      renderView1.AxesGrid.ZLabelBold = 1

      # register the view with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the images, etc.
      coprocessor.RegisterView(renderView1,
          filename='image_%t.png', freq=1, fittoscreen=0, magnification=1, width=1158, height=756, cinema={})
      renderView1.ViewTime = datadescription.GetTime()

      # ----------------------------------------------------------------
      # setup the data processing pipelines
      # ----------------------------------------------------------------

      # create a new 'XML MultiBlock Data Reader'
      # create a producer from a simulation input
      atm_input3d_ = coprocessor.CreateProducer(datadescription, 'atm_input3d')

      # create a new 'XML MultiBlock Data Reader'
      # create a producer from a simulation input
      atm_input2d_ = coprocessor.CreateProducer(datadescription, 'atm_input2d')

      # create a new 'Calculator'
      calculator1 = Calculator(Input=atm_input2d_)
      calculator1.ResultArrayName = 'topo_masked'
      calculator1.Function = 'topo*mask'

      # create a new 'Calculator'
      calculator3 = Calculator(Input=atm_input2d_)
      calculator3.ResultArrayName = 'prec_in_mm_day'
      calculator3.Function = 'abs(prec)*86400.0'

      # create a new 'Merge Blocks'
      mergeBlocks2 = MergeBlocks(Input=atm_input2d_)

      # create a new 'Calculator'
      calculator2 = Calculator(Input=mergeBlocks2)
      calculator2.ResultArrayName = 'wind_vec'
      calculator2.Function = 'wndu*iHat+wndv*jHat'

      # create a new 'Threshold'
      threshold2 = Threshold(Input=calculator1)
      threshold2.Scalars = ['POINTS', 'topo_masked']
      threshold2.ThresholdRange = [1e-09, 3428.5]

      # create a new 'Warp By Scalar'
      warpByScalar1 = WarpByScalar(Input=threshold2)
      warpByScalar1.Scalars = ['POINTS', 'topo_masked']
      warpByScalar1.ScaleFactor = 0.0001

      # create a new 'Transform'
      transform1 = Transform(Input=atm_input3d_)
      transform1.Transform = 'Transform'

      # init the 'Transform' selected for 'Transform'
      transform1.Transform.Scale = [1.0, 1.0, 0.0002]

      # create a new 'Glyph'
      glyph1 = Glyph(Input=calculator2,
          GlyphType='Arrow')
      glyph1.Scalars = ['POINTS', 'None']
      glyph1.Vectors = ['POINTS', 'wind_vec']
      glyph1.ScaleMode = 'vector'
      glyph1.ScaleFactor = 0.103645048141479
      glyph1.GlyphMode = 'Every Nth Point'
      glyph1.Stride = 9
      glyph1.GlyphTransform = 'Transform2'

      # init the 'Arrow' selected for 'GlyphType'
      glyph1.GlyphType.TipResolution = 36
      glyph1.GlyphType.ShaftResolution = 36

      # init the 'Transform2' selected for 'GlyphTransform'
      glyph1.GlyphTransform.Translate = [0.0, 0.0, -0.2]

      # create a new 'Merge Blocks'
      mergeBlocks1 = MergeBlocks(Input=transform1)

      # create a new 'Threshold'
      threshold1 = Threshold(Input=mergeBlocks1)
      threshold1.Scalars = ['POINTS', 'qlev']
      threshold1.ThresholdRange = [0.9, 1.00784758004649]

      # create a new 'Programmable Filter'
      programmableFilter1 = ProgrammableFilter(Input=threshold1)
      programmableFilter1.Script = 'import paraview.simple\nimport paraview.servermanager\nimport datetime\nimport locale\n\n# set epoc for date calculations\nlocale.setlocale(locale.LC_TIME, "en_US")\nepoc = datetime.datetime(2012, 1, 2, 0, 0, 0)\n\n# prapere input and output ports\nout = self.GetOutput()\nout.ShallowCopy(self.GetInput())\n\n# get time information\ntimeval = self.GetInput().GetInformation().Get(out.DATA_TIME_STEP())\n\n# find current time by adding elapsed time\ntimecur = epoc+datetime.timedelta(seconds=timeval)\ntimecur_str = timecur.strftime("%d-%b-%Y %H:%M:%S UTC")\n\n# output\nlabel = vtk.vtkStringArray()\nlabel.SetNumberOfComponents(1)\nlabel.Resize(1)\nlabel.SetName("TimeLabel")\nlabel.SetValue(0, timecur_str)\nout.GetFieldData().AddArray(label)'
      programmableFilter1.RequestInformationScript = ''
      programmableFilter1.RequestUpdateExtentScript = ''
      programmableFilter1.PythonPath = ''

      # create a new 'Annotate Global Data'
      annotateGlobalData1 = AnnotateGlobalData(Input=programmableFilter1)
      annotateGlobalData1.SelectArrays = 'TimeLabel'
      annotateGlobalData1.Prefix = 'Simulation Time: '

      # ----------------------------------------------------------------
      # setup color maps and opacity mapes used in the visualization
      # note: the Get..() functions create a new object, if needed
      # ----------------------------------------------------------------

      # get color transfer function/color map for 'GlyphVector'
      glyphVectorLUT = GetColorTransferFunction('GlyphVector')
      glyphVectorLUT.LockDataRange = 1
      glyphVectorLUT.RGBPoints = [0.0, 0.231373, 0.298039, 0.752941, 10.0, 0.865003, 0.865003, 0.865003, 20.0, 0.705882, 0.0156863, 0.14902]
      glyphVectorLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'GlyphVector'
      glyphVectorPWF = GetOpacityTransferFunction('GlyphVector')
      glyphVectorPWF.Points = [0.0, 0.0, 0.5, 0.0, 20.0, 1.0, 0.5, 0.0]
      glyphVectorPWF.ScalarRangeInitialized = 1

      # get color transfer function/color map for 'prec_in_mm_day'
      prec_in_mm_dayLUT = GetColorTransferFunction('prec_in_mm_day')
      prec_in_mm_dayLUT.LockDataRange = 1
      prec_in_mm_dayLUT.RGBPoints = [0.004999999999999999, 0.0, 0.0, 0.5625, 0.01391278277308779, 0.0, 0.0, 1.0, 0.1443072013968972, 0.0, 1.0, 1.0, 0.4647549289129509, 0.5, 1.0, 0.5, 1.4967870061786552, 1.0, 1.0, 0.0, 15.525085633241982, 1.0, 0.0, 0.0, 49.99999999999999, 0.5, 0.0, 0.0]
      prec_in_mm_dayLUT.UseLogScale = 1
      prec_in_mm_dayLUT.ColorSpace = 'RGB'
      prec_in_mm_dayLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'prec_in_mm_day'
      prec_in_mm_dayPWF = GetOpacityTransferFunction('prec_in_mm_day')
      prec_in_mm_dayPWF.Points = [0.0, 0.0, 0.5, 0.0, 50.0, 1.0, 0.5, 0.0]
      prec_in_mm_dayPWF.ScalarRangeInitialized = 1

      # get color transfer function/color map for 'qlev'
      qlevLUT = GetColorTransferFunction('qlev')
      qlevLUT.RGBPoints = [0.900000230270027, 0.0, 0.0, 0.0, 1.007846368329553, 1.0, 1.0, 1.0]
      qlevLUT.ColorSpace = 'RGB'
      qlevLUT.NanColor = [1.0, 0.0, 0.0]
      qlevLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'qlev'
      qlevPWF = GetOpacityTransferFunction('qlev')
      qlevPWF.Points = [0.900000230270027, 0.0, 0.5, 0.0, 1.007846368329553, 1.0, 0.5, 0.0]
      qlevPWF.ScalarRangeInitialized = 1

      # get color transfer function/color map for 'topo_masked'
      topo_maskedLUT = GetColorTransferFunction('topo_masked')
      topo_maskedLUT.LockDataRange = 1
      topo_maskedLUT.RGBPoints = [0.00701846461743116, 0.141176, 0.14902, 0.2, 171.431667541387, 0.215686, 0.258824, 0.321569, 342.856316618156, 0.243137, 0.368627, 0.380392, 514.280965694925, 0.27451, 0.439216, 0.4, 685.705614771694, 0.32549, 0.501961, 0.384314, 857.130263848463, 0.403922, 0.6, 0.419608, 1028.55491292523, 0.486275, 0.701961, 0.454902, 1199.979562002, 0.556863, 0.74902, 0.494118, 1371.40421107877, 0.670588, 0.8, 0.545098, 1714.25350923231, 0.854902, 0.901961, 0.631373, 1885.67815830908, 0.92549, 0.941176, 0.694118, 2057.10280738585, 0.960784, 0.94902, 0.776471, 2228.52745646262, 0.988235, 0.968627, 0.909804, 2399.95210553939, 0.839216, 0.815686, 0.772549, 2571.37675461615, 0.701961, 0.662745, 0.615686, 2742.80140369292, 0.6, 0.529412, 0.478431, 2914.22605276969, 0.501961, 0.403922, 0.360784, 3085.65070184646, 0.439216, 0.313725, 0.290196, 3428.5, 0.301961, 0.164706, 0.176471]
      topo_maskedLUT.ColorSpace = 'Lab'
      topo_maskedLUT.UseAboveRangeColor = 1
      topo_maskedLUT.AboveRangeColor = [0.784313725490196, 0.784313725490196, 0.784313725490196]
      topo_maskedLUT.NanColor = [0.25, 0.0, 0.0]
      topo_maskedLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'topo_masked'
      topo_maskedPWF = GetOpacityTransferFunction('topo_masked')
      topo_maskedPWF.Points = [0.00701846461743116, 0.0, 0.5, 0.0, 3428.5, 1.0, 0.5, 0.0]
      topo_maskedPWF.ScalarRangeInitialized = 1

      # ----------------------------------------------------------------
      # setup the visualization in view 'renderView1'
      # ----------------------------------------------------------------

      # show data from threshold1
      threshold1Display = Show(threshold1, renderView1)
      # trace defaults for the display properties.
      threshold1Display.Representation = 'Volume'
      threshold1Display.ColorArrayName = ['POINTS', 'qlev']
      threshold1Display.LookupTable = qlevLUT
      threshold1Display.OSPRayScaleArray = 'qlev'
      threshold1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      threshold1Display.SelectOrientationVectors = 'None'
      threshold1Display.ScaleFactor = 3.56160907745361
      threshold1Display.SelectScaleArray = 'None'
      threshold1Display.GlyphType = 'Arrow'
      threshold1Display.ScalarOpacityUnitDistance = 0.4
      threshold1Display.SelectMapper = 'Bunyk ray cast'
      threshold1Display.GaussianRadius = 1.78080453872681
      threshold1Display.SetScaleArray = ['POINTS', 'qlev']
      threshold1Display.ScaleTransferFunction = 'PiecewiseFunction'
      threshold1Display.OpacityArray = ['POINTS', 'qlev']
      threshold1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show color legend
      threshold1Display.SetScalarBarVisibility(renderView1, True)

      # show data from annotateGlobalData1
      annotateGlobalData1Display = Show(annotateGlobalData1, renderView1)
      # trace defaults for the display properties.
      annotateGlobalData1Display.FontSize = 8
      annotateGlobalData1Display.WindowLocation = 'AnyLocation'
      annotateGlobalData1Display.Position = [0.117342238454958, 0.016887417218543]

      # show data from warpByScalar1
      warpByScalar1Display = Show(warpByScalar1, renderView1)
      # trace defaults for the display properties.
      warpByScalar1Display.ColorArrayName = ['POINTS', 'topo_masked']
      warpByScalar1Display.LookupTable = topo_maskedLUT
      warpByScalar1Display.InterpolateScalarsBeforeMapping = 0
      warpByScalar1Display.OSPRayScaleArray = 'topo_masked'
      warpByScalar1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      warpByScalar1Display.SelectOrientationVectors = 'None'
      warpByScalar1Display.ScaleFactor = 3.45483493804932
      warpByScalar1Display.SelectScaleArray = 'topo_masked'
      warpByScalar1Display.GlyphType = 'Arrow'
      warpByScalar1Display.ScalarOpacityUnitDistance = 1.25821737420322
      warpByScalar1Display.GaussianRadius = 1.72741746902466
      warpByScalar1Display.SetScaleArray = ['POINTS', 'topo_masked']
      warpByScalar1Display.ScaleTransferFunction = 'PiecewiseFunction'
      warpByScalar1Display.OpacityArray = ['POINTS', 'topo_masked']
      warpByScalar1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show data from glyph1
      glyph1Display = Show(glyph1, renderView1)
      # trace defaults for the display properties.
      glyph1Display.ColorArrayName = ['POINTS', 'GlyphVector']
      glyph1Display.LookupTable = glyphVectorLUT
      glyph1Display.Opacity = 0.4
      glyph1Display.OSPRayScaleArray = 'topo_masked'
      glyph1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      glyph1Display.SelectOrientationVectors = 'GlyphVector'
      glyph1Display.ScaleFactor = 3.69372806549072
      glyph1Display.SelectScaleArray = 'topo_masked'
      glyph1Display.GlyphType = 'Arrow'
      glyph1Display.GaussianRadius = 1.84686403274536
      glyph1Display.SetScaleArray = ['POINTS', 'topo_masked']
      glyph1Display.ScaleTransferFunction = 'PiecewiseFunction'
      glyph1Display.OpacityArray = ['POINTS', 'topo_masked']
      glyph1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show color legend
      glyph1Display.SetScalarBarVisibility(renderView1, True)

      # show data from calculator3
      calculator3Display = Show(calculator3, renderView1)
      # trace defaults for the display properties.
      calculator3Display.ColorArrayName = ['POINTS', 'prec_in_mm_day']
      calculator3Display.LookupTable = prec_in_mm_dayLUT
      calculator3Display.OSPRayScaleArray = 'mask'
      calculator3Display.OSPRayScaleFunction = 'PiecewiseFunction'
      calculator3Display.SelectOrientationVectors = 'None'
      calculator3Display.ScaleFactor = 3.56160907745361
      calculator3Display.SelectScaleArray = 'None'
      calculator3Display.GlyphType = 'Arrow'
      calculator3Display.ScalarOpacityUnitDistance = 1.09741261745601

      # show color legend
      calculator3Display.SetScalarBarVisibility(renderView1, True)

      # setup the color legend parameters for each legend in this view

      # get color legend/bar for qlevLUT in view renderView1
      qlevLUTColorBar = GetScalarBar(qlevLUT, renderView1)
      qlevLUTColorBar.Position = [0.46831404763213, 0.920033112582782]
      qlevLUTColorBar.Position2 = [0.430000000000001, 0.12]
      qlevLUTColorBar.Orientation = 'Horizontal'
      qlevLUTColorBar.Title = 'Relative Humidity (0-1)'
      qlevLUTColorBar.ComponentTitle = ''
      qlevLUTColorBar.TitleBold = 1
      qlevLUTColorBar.TitleFontSize = 4
      qlevLUTColorBar.LabelBold = 1
      qlevLUTColorBar.LabelFontSize = 4
      qlevLUTColorBar.RangeLabelFormat = '%4.1f'
      qlevLUTColorBar.TextPosition = 'Ticks left/bottom, annotations right/top'
      qlevLUTColorBar.AspectRatio = 60.0

      # get color legend/bar for glyphVectorLUT in view renderView1
      glyphVectorLUTColorBar = GetScalarBar(glyphVectorLUT, renderView1)
      glyphVectorLUTColorBar.Position = [0.00841209173036786, 0.919668874172185]
      glyphVectorLUTColorBar.Position2 = [0.43, 0.120000000000002]
      glyphVectorLUTColorBar.AutoOrient = 0
      glyphVectorLUTColorBar.Orientation = 'Horizontal'
      glyphVectorLUTColorBar.Title = 'Surface Wind'
      glyphVectorLUTColorBar.ComponentTitle = 'Magnitude (m/s)'
      glyphVectorLUTColorBar.TitleBold = 1
      glyphVectorLUTColorBar.TitleFontSize = 4
      glyphVectorLUTColorBar.LabelBold = 1
      glyphVectorLUTColorBar.LabelFontSize = 4
      glyphVectorLUTColorBar.RangeLabelFormat = '%4.1f'
      glyphVectorLUTColorBar.TextPosition = 'Ticks left/bottom, annotations right/top'
      glyphVectorLUTColorBar.AspectRatio = 60.0

      # get color legend/bar for prec_in_mm_dayLUT in view renderView1
      prec_in_mm_dayLUTColorBar = GetScalarBar(prec_in_mm_dayLUT, renderView1)
      prec_in_mm_dayLUTColorBar.Position = [0.00701382886776142, 0.826192052980132]
      prec_in_mm_dayLUTColorBar.Position2 = [0.43, 0.12]
      prec_in_mm_dayLUTColorBar.AutoOrient = 0
      prec_in_mm_dayLUTColorBar.Orientation = 'Horizontal'
      prec_in_mm_dayLUTColorBar.Title = 'Total Precipitation (mm/day)'
      prec_in_mm_dayLUTColorBar.ComponentTitle = ''
      prec_in_mm_dayLUTColorBar.TitleBold = 1
      prec_in_mm_dayLUTColorBar.TitleFontSize = 4
      prec_in_mm_dayLUTColorBar.LabelBold = 1
      prec_in_mm_dayLUTColorBar.LabelFontSize = 4
      prec_in_mm_dayLUTColorBar.RangeLabelFormat = '%4.1f'
      prec_in_mm_dayLUTColorBar.TextPosition = 'Ticks left/bottom, annotations right/top'
      prec_in_mm_dayLUTColorBar.AspectRatio = 60.0

      # ----------------------------------------------------------------
      # finally, restore active source
      SetActiveSource(calculator3)
      # ----------------------------------------------------------------
    return Pipeline()

  class CoProcessor(coprocessing.CoProcessor):
    def CreatePipeline(self, datadescription):
      self.Pipeline = _CreatePipeline(self, datadescription)

  coprocessor = CoProcessor()
  # these are the frequencies at which the coprocessor updates.
  freqs = {'atm_input2d': [1, 1, 1, 1, 1, 1, 1, 1], 'atm_input3d': [1, 1, 1, 1, 1, 1]}
  coprocessor.SetUpdateFrequencies(freqs)
  return coprocessor

#--------------------------------------------------------------
# Global variables that will hold the pipeline for each timestep
# Creating the CoProcessor object, doesn't actually create the ParaView pipeline.
# It will be automatically setup when coprocessor.UpdateProducers() is called the
# first time.
coprocessor = CreateCoProcessor()

#--------------------------------------------------------------
# Enable Live-Visualizaton with ParaView
coprocessor.EnableLiveVisualization(False, 1)
#coprocessor.EnableLiveVisualization(True, 1)


# ---------------------- Data Selection method ----------------------

def RequestDataDescription(datadescription):
    "Callback to populate the request for current timestep"
    global coprocessor
    if datadescription.GetForceOutput() == True:
        # We are just going to request all fields and meshes from the simulation
        # code/adaptor.
        for i in range(datadescription.GetNumberOfInputDescriptions()):
            datadescription.GetInputDescription(i).AllFieldsOn()
            datadescription.GetInputDescription(i).GenerateMeshOn()
        return

    # setup requests for all inputs based on the requirements of the
    # pipeline.
    coprocessor.LoadRequestedData(datadescription)

# ------------------------ Processing method ------------------------

def DoCoProcessing(datadescription):
    "Callback to do co-processing for current timestep"
    global coprocessor

    # Update the coprocessor by providing it the newly generated simulation data.
    # If the pipeline hasn't been setup yet, this will setup the pipeline.
    coprocessor.UpdateProducers(datadescription)

    # Write output data, if appropriate.
    coprocessor.WriteData(datadescription);

    # Write image capture (Last arg: rescale lookup table), if appropriate.
    coprocessor.WriteImages(datadescription, rescale_lookuptable=False)

    # Live Visualization, if enabled.
    coprocessor.DoLiveVisualization(datadescription, "localhost", 22222)
