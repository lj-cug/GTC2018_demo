
from paraview.simple import *
from paraview import coprocessing


#--------------------------------------------------------------
# Code generated from cpstate.py to create the CoProcessor.
# ParaView 5.1.0 64 bits


# ----------------------- CoProcessor definition -----------------------

def CreateCoProcessor():
  def _CreatePipeline(coprocessor, datadescription):
    class Pipeline:
      # state file generated using paraview version 5.1.0

      # ----------------------------------------------------------------
      # setup views used in the visualization
      # ----------------------------------------------------------------

      #### disable automatic camera reset on 'Show'
      paraview.simple._DisableFirstRenderCameraReset()

      # Create a new 'Render View'
      renderView1 = CreateView('RenderView')
      renderView1.ViewSize = [1156, 756]
      renderView1.AxesGrid = 'GridAxes3DActor'
      renderView1.CenterOfRotation = [34.499999046325684, 39.59470844268799, 2.799498438835144]
      renderView1.StereoType = 0
      renderView1.CameraPosition = [27.811977549856568, 34.34785858514448, 55.634836734865544]
      renderView1.CameraFocalPoint = [37.408581145607634, 41.87653328151776, -20.178286434983196]
      renderView1.CameraViewUp = [0.23658785857672646, 0.9634545669509815, 0.12562437102479537]
      renderView1.CameraParallelScale = 24.084900304739293
      renderView1.Background = [0.32, 0.34, 0.43]

      # init the 'GridAxes3DActor' selected for 'AxesGrid'
      renderView1.AxesGrid.Visibility = 1
      renderView1.AxesGrid.XTitle = 'Longitude'
      renderView1.AxesGrid.YTitle = 'Latitude'

      # register the view with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the images, etc.
      coprocessor.RegisterView(renderView1,
          filename='image_%t.png', freq=1, fittoscreen=1, magnification=1, width=1156, height=756, cinema={})
      renderView1.ViewTime = datadescription.GetTime()

      # ----------------------------------------------------------------
      # setup the data processing pipelines
      # ----------------------------------------------------------------

      # create a new 'XML MultiBlock Data Reader'
      # create a producer from a simulation input
      atm_input2d_ = coprocessor.CreateProducer(datadescription, 'atm_input2d')

      # create a new 'Threshold'
      threshold1 = Threshold(Input=atm_input2d_)
      threshold1.Scalars = ['POINTS', 'tsfc']
      threshold1.ThresholdRange = [260.0, 300.0]

      # ----------------------------------------------------------------
      # setup color maps and opacity mapes used in the visualization
      # note: the Get..() functions create a new object, if needed
      # ----------------------------------------------------------------

      # get color transfer function/color map for 'tsfc'
      tsfcLUT = GetColorTransferFunction('tsfc')
      tsfcLUT.LockDataRange = 1
      tsfcLUT.RGBPoints = [266.0, 0.278431372549, 0.278431372549, 0.858823529412, 270.004, 0.0, 0.0, 0.360784313725, 273.98, 0.0, 1.0, 1.0, 278.012, 0.0, 0.501960784314, 0.0, 281.988, 1.0, 1.0, 0.0, 285.992, 1.0, 0.380392156863, 0.0, 289.996, 0.419607843137, 0.0, 0.0, 294.0, 0.878431372549, 0.301960784314, 0.301960784314]
      tsfcLUT.ColorSpace = 'RGB'
      tsfcLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'tsfc'
      tsfcPWF = GetOpacityTransferFunction('tsfc')
      tsfcPWF.Points = [266.0, 0.0, 0.5, 0.0, 294.0, 1.0, 0.5, 0.0]
      tsfcPWF.ScalarRangeInitialized = 1

      # ----------------------------------------------------------------
      # setup the visualization in view 'renderView1'
      # ----------------------------------------------------------------

      # show data from threshold1
      threshold1Display = Show(threshold1, renderView1)
      # trace defaults for the display properties.
      threshold1Display.ColorArrayName = ['POINTS', 'tsfc']
      threshold1Display.LookupTable = tsfcLUT
      threshold1Display.OSPRayScaleArray = 'tsfc'
      threshold1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      threshold1Display.GlyphType = 'Arrow'
      threshold1Display.ScalarOpacityUnitDistance = 1.090793294861386

      # show color legend
      threshold1Display.SetScalarBarVisibility(renderView1, True)

      # setup the color legend parameters for each legend in this view

      # get color legend/bar for tsfcLUT in view renderView1
      tsfcLUTColorBar = GetScalarBar(tsfcLUT, renderView1)
      tsfcLUTColorBar.Position = [0.024870129870129903, 0.8659271523178808]
      tsfcLUTColorBar.Position2 = [0.4299999999999997, 0.1200000000000001]
      tsfcLUTColorBar.Orientation = 'Horizontal'
      tsfcLUTColorBar.Title = 'Surface Air Temperature (degC)'
      tsfcLUTColorBar.ComponentTitle = ''
      tsfcLUTColorBar.TitleFontSize = 6
      tsfcLUTColorBar.LabelFontSize = 6
      tsfcLUTColorBar.RangeLabelFormat = '%4.0f'
      tsfcLUTColorBar.AspectRatio = 30.0

      # ----------------------------------------------------------------
      # finally, restore active source
      SetActiveSource(threshold1)
      # ----------------------------------------------------------------
    return Pipeline()

  class CoProcessor(coprocessing.CoProcessor):
    def CreatePipeline(self, datadescription):
      self.Pipeline = _CreatePipeline(self, datadescription)

  coprocessor = CoProcessor()
  # these are the frequencies at which the coprocessor updates.
  freqs = {'atm_input2d': [1, 1]}
  coprocessor.SetUpdateFrequencies(freqs)
  return coprocessor

#--------------------------------------------------------------
# Global variables that will hold the pipeline for each timestep
# Creating the CoProcessor object, doesn't actually create the ParaView pipeline.
# It will be automatically setup when coprocessor.UpdateProducers() is called the
# first time.
coprocessor = CreateCoProcessor()

#--------------------------------------------------------------
# Enable Live-Visualizaton with ParaView
coprocessor.EnableLiveVisualization(False, 1)
#coprocessor.EnableLiveVisualization(True, 1)


# ---------------------- Data Selection method ----------------------

def RequestDataDescription(datadescription):
    "Callback to populate the request for current timestep"
    global coprocessor
    if datadescription.GetForceOutput() == True:
        # We are just going to request all fields and meshes from the simulation
        # code/adaptor.
        for i in range(datadescription.GetNumberOfInputDescriptions()):
            datadescription.GetInputDescription(i).AllFieldsOn()
            datadescription.GetInputDescription(i).GenerateMeshOn()
        return

    # setup requests for all inputs based on the requirements of the
    # pipeline.
    coprocessor.LoadRequestedData(datadescription)

# ------------------------ Processing method ------------------------

def DoCoProcessing(datadescription):
    "Callback to do co-processing for current timestep"
    global coprocessor

    # Update the coprocessor by providing it the newly generated simulation data.
    # If the pipeline hasn't been setup yet, this will setup the pipeline.
    coprocessor.UpdateProducers(datadescription)

    # Write output data, if appropriate.
    coprocessor.WriteData(datadescription);

    # Write image capture (Last arg: rescale lookup table), if appropriate.
    coprocessor.WriteImages(datadescription, rescale_lookuptable=False)

    # Live Visualization, if enabled.
    coprocessor.DoLiveVisualization(datadescription, "localhost", 22222)
