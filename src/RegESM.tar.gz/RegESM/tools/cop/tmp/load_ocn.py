from paraview.simple import *
import glob, os, sys

paraview.simple._DisableFirstRenderCameraReset()

os.chdir("/Users/turuncu/Desktop/a")

for file in glob.glob("ocean_CROSSpoint*.vtk"):
    # create a new 'Legacy VTK Reader'
    ocean_CROSSpoint9600vtk = LegacyVTKReader(FileNames=[file])

    # get active view
    renderView1 = GetActiveViewOrCreate('RenderView')
    # uncomment following to set a specific view size
    # renderView1.ViewSize = [1037, 597]

    # get color transfer function/color map for 'NODENUM'
    nODENUMLUT = GetColorTransferFunction('NODENUM')

    # show data in view
    ocean_CROSSpoint9600vtkDisplay = Show(ocean_CROSSpoint9600vtk, renderView1)

    # trace defaults for the display properties.
    ocean_CROSSpoint9600vtkDisplay.ColorArrayName = ['POINTS', '_NODE_NUM']
    ocean_CROSSpoint9600vtkDisplay.LookupTable = nODENUMLUT
    ocean_CROSSpoint9600vtkDisplay.GlyphType = 'Arrow'
    ocean_CROSSpoint9600vtkDisplay.ScalarOpacityUnitDistance = 0.008346303678152934
    ocean_CROSSpoint9600vtkDisplay.SelectInputVectors = [None, '']
    ocean_CROSSpoint9600vtkDisplay.WriteLog = ''

    # reset view to fit data
    renderView1.ResetCamera()

    # show color bar/color legend
    ocean_CROSSpoint9600vtkDisplay.SetScalarBarVisibility(renderView1, True)

    # get opacity transfer function/opacity map for 'NODENUM'
    nODENUMPWF = GetOpacityTransferFunction('NODENUM')

    # change representation type
    ocean_CROSSpoint9600vtkDisplay.SetRepresentationType('Points')

    # turn off scalar coloring
    ColorBy(ocean_CROSSpoint9600vtkDisplay, None)

    # change solid color
    ocean_CROSSpoint9600vtkDisplay.AmbientColor = [1.0, 0.0, 0.0]

    #### saving camera placements for all active views

    # current camera placement for renderView1
    renderView1.CameraPosition = [1.0222067016254641, -0.15979486107697174, 0.5684410803196048]
    renderView1.CameraFocalPoint = [0.8464885, -0.12244665, 0.5162175]
    renderView1.CameraViewUp = [-0.2119815751806137, 0.30219392187625216, 0.9293775580274121]
    renderView1.CameraParallelScale = 0.048419971544007546

    #### uncomment the following to render all views
    # RenderAllViews()
    # alternatively, if you want to write images, you can use SaveScreenshot(...).
sys.exit()
for file in glob.glob("ocean_DOTpoint*.vtk"):
    # create a new 'Legacy VTK Reader'
    ocean_CROSSpoint9600vtk = LegacyVTKReader(FileNames=[file])

    # get active view
    renderView1 = GetActiveViewOrCreate('RenderView')
    # uncomment following to set a specific view size
    # renderView1.ViewSize = [1037, 597]

    # get color transfer function/color map for 'NODENUM'
    nODENUMLUT = GetColorTransferFunction('NODENUM')

    # show data in view
    ocean_CROSSpoint9600vtkDisplay = Show(ocean_CROSSpoint9600vtk, renderView1)

    # trace defaults for the display properties.
    ocean_CROSSpoint9600vtkDisplay.ColorArrayName = ['POINTS', '_NODE_NUM']
    ocean_CROSSpoint9600vtkDisplay.LookupTable = nODENUMLUT
    ocean_CROSSpoint9600vtkDisplay.GlyphType = 'Arrow'
    ocean_CROSSpoint9600vtkDisplay.ScalarOpacityUnitDistance = 0.008346303678152934
    ocean_CROSSpoint9600vtkDisplay.SelectInputVectors = [None, '']
    ocean_CROSSpoint9600vtkDisplay.WriteLog = ''

    # reset view to fit data
    renderView1.ResetCamera()

    # show color bar/color legend
    ocean_CROSSpoint9600vtkDisplay.SetScalarBarVisibility(renderView1, True)

    # get opacity transfer function/opacity map for 'NODENUM'
    nODENUMPWF = GetOpacityTransferFunction('NODENUM')

    # change representation type
    ocean_CROSSpoint9600vtkDisplay.SetRepresentationType('Points')

    # turn off scalar coloring
    ColorBy(ocean_CROSSpoint9600vtkDisplay, None)

    # change solid color
    ocean_CROSSpoint9600vtkDisplay.AmbientColor = [0.0, 1.0, 0.0]

for file in glob.glob("ocean_Upoint*.vtk"):
    # create a new 'Legacy VTK Reader'
    ocean_CROSSpoint9600vtk = LegacyVTKReader(FileNames=[file])

    # get active view
    renderView1 = GetActiveViewOrCreate('RenderView')
    # uncomment following to set a specific view size
    # renderView1.ViewSize = [1037, 597]

    # get color transfer function/color map for 'NODENUM'
    nODENUMLUT = GetColorTransferFunction('NODENUM')

    # show data in view
    ocean_CROSSpoint9600vtkDisplay = Show(ocean_CROSSpoint9600vtk, renderView1)

    # trace defaults for the display properties.
    ocean_CROSSpoint9600vtkDisplay.ColorArrayName = ['POINTS', '_NODE_NUM']
    ocean_CROSSpoint9600vtkDisplay.LookupTable = nODENUMLUT
    ocean_CROSSpoint9600vtkDisplay.GlyphType = 'Arrow'
    ocean_CROSSpoint9600vtkDisplay.ScalarOpacityUnitDistance = 0.008346303678152934
    ocean_CROSSpoint9600vtkDisplay.SelectInputVectors = [None, '']
    ocean_CROSSpoint9600vtkDisplay.WriteLog = ''

    # reset view to fit data
    renderView1.ResetCamera()

    # show color bar/color legend
    ocean_CROSSpoint9600vtkDisplay.SetScalarBarVisibility(renderView1, True)

    # get opacity transfer function/opacity map for 'NODENUM'
    nODENUMPWF = GetOpacityTransferFunction('NODENUM')

    # change representation type
    ocean_CROSSpoint9600vtkDisplay.SetRepresentationType('Points')

    # turn off scalar coloring
    ColorBy(ocean_CROSSpoint9600vtkDisplay, None)

    # change solid color
    ocean_CROSSpoint9600vtkDisplay.AmbientColor = [0.0, 0.0, 1.0]

for file in glob.glob("ocean_Vpoint*.vtk"):
    # create a new 'Legacy VTK Reader'
    ocean_CROSSpoint9600vtk = LegacyVTKReader(FileNames=[file])

    # get active view
    renderView1 = GetActiveViewOrCreate('RenderView')
    # uncomment following to set a specific view size
    # renderView1.ViewSize = [1037, 597]

    # get color transfer function/color map for 'NODENUM'
    nODENUMLUT = GetColorTransferFunction('NODENUM')

    # show data in view
    ocean_CROSSpoint9600vtkDisplay = Show(ocean_CROSSpoint9600vtk, renderView1)

    # trace defaults for the display properties.
    ocean_CROSSpoint9600vtkDisplay.ColorArrayName = ['POINTS', '_NODE_NUM']
    ocean_CROSSpoint9600vtkDisplay.LookupTable = nODENUMLUT
    ocean_CROSSpoint9600vtkDisplay.GlyphType = 'Arrow'
    ocean_CROSSpoint9600vtkDisplay.ScalarOpacityUnitDistance = 0.008346303678152934
    ocean_CROSSpoint9600vtkDisplay.SelectInputVectors = [None, '']
    ocean_CROSSpoint9600vtkDisplay.WriteLog = ''

    # reset view to fit data
    renderView1.ResetCamera()

    # show color bar/color legend
    ocean_CROSSpoint9600vtkDisplay.SetScalarBarVisibility(renderView1, True)

    # get opacity transfer function/opacity map for 'NODENUM'
    nODENUMPWF = GetOpacityTransferFunction('NODENUM')

    # change representation type
    ocean_CROSSpoint9600vtkDisplay.SetRepresentationType('Points')

    # turn off scalar coloring
    ColorBy(ocean_CROSSpoint9600vtkDisplay, None)

    # change solid color
    ocean_CROSSpoint9600vtkDisplay.AmbientColor = [0.93, 0.0, 1.0]
