
from paraview.simple import *
from paraview import coprocessing


#--------------------------------------------------------------
# Code generated from cpstate.py to create the CoProcessor.
# ParaView 5.2.0-RC3 64 bits


# ----------------------- CoProcessor definition -----------------------

def CreateCoProcessor():
  def _CreatePipeline(coprocessor, datadescription):
    class Pipeline:
      # state file generated using paraview version 5.2.0-RC3

      # ----------------------------------------------------------------
      # setup views used in the visualization
      # ----------------------------------------------------------------

      #### disable automatic camera reset on 'Show'
      paraview.simple._DisableFirstRenderCameraReset()

      # Create a new 'Render View'
      renderView1 = CreateView('RenderView')
      renderView1.ViewSize = [1554, 756]
      renderView1.AxesGrid = 'GridAxes3DActor'
      renderView1.CenterOfRotation = [34.5676107406616, 41.595760345459, 1.002]
      renderView1.StereoType = 0
      renderView1.CameraPosition = [11.61717660939287, 26.554894220511724, 22.326020354929348]
      renderView1.CameraFocalPoint = [34.65824386990966, 41.65515794794951, 0.9177897109105118]
      renderView1.CameraViewUp = [0.24084719012434333, 0.6519041543708579, 0.7190365807962937]
      renderView1.CameraParallelScale = 1.73205080756888
      renderView1.Background = [0.32, 0.34, 0.43]

      # init the 'GridAxes3DActor' selected for 'AxesGrid'
      renderView1.AxesGrid.Visibility = 1
      renderView1.AxesGrid.XTitle = 'Longitude'
      renderView1.AxesGrid.YTitle = 'Latitude'
      renderView1.AxesGrid.ZTitle = 'Height (m)'
      renderView1.AxesGrid.XTitleBold = 1
      renderView1.AxesGrid.YTitleBold = 1
      renderView1.AxesGrid.ZTitleBold = 1
      renderView1.AxesGrid.XLabelBold = 1
      renderView1.AxesGrid.YLabelBold = 1
      renderView1.AxesGrid.ZLabelBold = 1

      # register the view with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the images, etc.
      coprocessor.RegisterView(renderView1,
          filename='image_%t.png', freq=1, fittoscreen=0, magnification=1, width=1554, height=756, cinema={})
      renderView1.ViewTime = datadescription.GetTime()

      # ----------------------------------------------------------------
      # setup the data processing pipelines
      # ----------------------------------------------------------------

      # create a new 'XML MultiBlock Data Reader'
      # create a producer from a simulation input
      atm_input2d_ = coprocessor.CreateProducer(datadescription, 'atm_input2d')

      # create a new 'Calculator'
      calculator1 = Calculator(Input=atm_input2d_)
      calculator1.ResultArrayName = 'topo_masked'
      calculator1.Function = 'topo*mask'

      # create a new 'Threshold'
      threshold2 = Threshold(Input=calculator1)
      threshold2.Scalars = ['POINTS', 'topo_masked']
      threshold2.ThresholdRange = [1e-09, 3428.5]

      # create a new 'Merge Blocks'
      mergeBlocks2 = MergeBlocks(Input=atm_input2d_)

      # create a new 'Warp By Scalar'
      warpByScalar1 = WarpByScalar(Input=threshold2)
      warpByScalar1.Scalars = ['POINTS', 'topo_masked']
      warpByScalar1.ScaleFactor = 0.0001

      # create a new 'XML MultiBlock Data Reader'
      # create a producer from a simulation input
      atm_input3d_ = coprocessor.CreateProducer(datadescription, 'atm_input3d')

      # create a new 'Transform'
      transform1 = Transform(Input=atm_input3d_)
      transform1.Transform = 'Transform'

      # init the 'Transform' selected for 'Transform'
      transform1.Transform.Scale = [1.0, 1.0, 0.0002]

      # create a new 'Merge Blocks'
      mergeBlocks1 = MergeBlocks(Input=transform1)

      # create a new 'Threshold'
      threshold1 = Threshold(Input=mergeBlocks1)
      threshold1.Scalars = ['POINTS', 'qlev']
      threshold1.ThresholdRange = [0.9, 1.00784758004649]

      # create a new 'Programmable Filter'
      programmableFilter1 = ProgrammableFilter(Input=threshold1)
      programmableFilter1.Script = 'import paraview.simple\nimport paraview.servermanager\nimport datetime\nimport locale\n\n# set epoc for date calculations\nlocale.setlocale(locale.LC_TIME, "en_US")\nepoc = datetime.datetime(2012, 1, 2, 0, 0, 0)\n\n# prapere input and output ports\nout = self.GetOutput()\nout.ShallowCopy(self.GetInput())\n\n# get time information\ntimeval = self.GetInput().GetInformation().Get(out.DATA_TIME_STEP())\n\n# find current time by adding elapsed time\ntimecur = epoc+datetime.timedelta(seconds=timeval)\ntimecur_str = timecur.strftime("%d-%b-%Y %H:%M:%S UTC")\n\n# output\nlabel = vtk.vtkStringArray()\nlabel.SetNumberOfComponents(1)\nlabel.Resize(1)\nlabel.SetName("TimeLabel")\nlabel.SetValue(0, timecur_str)\nout.GetFieldData().AddArray(label)'
      programmableFilter1.RequestInformationScript = ''
      programmableFilter1.RequestUpdateExtentScript = ''
      programmableFilter1.PythonPath = ''

      # create a new 'Annotate Global Data'
      annotateGlobalData1 = AnnotateGlobalData(Input=programmableFilter1)
      annotateGlobalData1.SelectArrays = 'TimeLabel'
      annotateGlobalData1.Prefix = 'Simulation Time: '

      # create a new 'Calculator'
      calculator2 = Calculator(Input=mergeBlocks2)
      calculator2.ResultArrayName = 'wind_vec'
      calculator2.Function = 'wndu*iHat+wndv*jHat'

      # create a new 'Glyph'
      glyph1 = Glyph(Input=calculator2,
          GlyphType='Arrow')
      glyph1.Scalars = ['POINTS', 'None']
      glyph1.Vectors = ['POINTS', 'wind_vec']
      glyph1.ScaleMode = 'vector'
      glyph1.ScaleFactor = 0.10364504814147948
      glyph1.GlyphMode = 'Every Nth Point'
      glyph1.Stride = 9
      glyph1.GlyphTransform = 'Transform2'

      # init the 'Arrow' selected for 'GlyphType'
      glyph1.GlyphType.TipResolution = 36
      glyph1.GlyphType.ShaftResolution = 36

      # init the 'Transform2' selected for 'GlyphTransform'
      glyph1.GlyphTransform.Translate = [0.0, 0.0, -0.2]

      # ----------------------------------------------------------------
      # setup color maps and opacity mapes used in the visualization
      # note: the Get..() functions create a new object, if needed
      # ----------------------------------------------------------------

      # get color transfer function/color map for 'GlyphVector'
      glyphVectorLUT = GetColorTransferFunction('GlyphVector')
      glyphVectorLUT.LockDataRange = 1
      glyphVectorLUT.RGBPoints = [0.0, 0.231373, 0.298039, 0.752941, 10.0, 0.865003, 0.865003, 0.865003, 20.0, 0.705882, 0.0156863, 0.14902]
      glyphVectorLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'GlyphVector'
      glyphVectorPWF = GetOpacityTransferFunction('GlyphVector')
      glyphVectorPWF.Points = [0.0, 0.0, 0.5, 0.0, 20.0, 1.0, 0.5, 0.0]
      glyphVectorPWF.ScalarRangeInitialized = 1

      # get color transfer function/color map for 'qlev'
      qlevLUT = GetColorTransferFunction('qlev')
      qlevLUT.RGBPoints = [0.9000005255687691, 0.0, 0.0, 0.0, 1.007838393570706, 1.0, 1.0, 1.0]
      qlevLUT.ColorSpace = 'RGB'
      qlevLUT.NanColor = [1.0, 0.0, 0.0]
      qlevLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'qlev'
      qlevPWF = GetOpacityTransferFunction('qlev')
      qlevPWF.Points = [0.9000005255687691, 0.0, 0.5, 0.0, 1.007838393570706, 1.0, 0.5, 0.0]
      qlevPWF.ScalarRangeInitialized = 1

      # get color transfer function/color map for 'topo_masked'
      topo_maskedLUT = GetColorTransferFunction('topo_masked')
      topo_maskedLUT.LockDataRange = 1
      topo_maskedLUT.RGBPoints = [0.007018464617431164, 0.141176, 0.14902, 0.2, 171.43166754138656, 0.215686, 0.258824, 0.321569, 342.8563166181557, 0.243137, 0.368627, 0.380392, 514.2809656949248, 0.27451, 0.439216, 0.4, 685.705614771694, 0.32549, 0.501961, 0.384314, 857.1302638484631, 0.403922, 0.6, 0.419608, 1028.5549129252322, 0.486275, 0.701961, 0.454902, 1199.9795620020013, 0.556863, 0.74902, 0.494118, 1371.4042110787705, 0.670588, 0.8, 0.545098, 1714.2535092323087, 0.854902, 0.901961, 0.631373, 1885.678158309078, 0.92549, 0.941176, 0.694118, 2057.102807385847, 0.960784, 0.94902, 0.776471, 2228.527456462616, 0.988235, 0.968627, 0.909804, 2399.9521055393852, 0.839216, 0.815686, 0.772549, 2571.3767546161544, 0.701961, 0.662745, 0.615686, 2742.8014036929235, 0.6, 0.529412, 0.478431, 2914.2260527696926, 0.501961, 0.403922, 0.360784, 3085.6507018464617, 0.439216, 0.313725, 0.290196, 3428.5, 0.301961, 0.164706, 0.176471]
      topo_maskedLUT.ColorSpace = 'Lab'
      topo_maskedLUT.UseAboveRangeColor = 1
      topo_maskedLUT.AboveRangeColor = [0.7843137254901961, 0.7843137254901961, 0.7843137254901961]
      topo_maskedLUT.NanColor = [0.25, 0.0, 0.0]
      topo_maskedLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'topo_masked'
      topo_maskedPWF = GetOpacityTransferFunction('topo_masked')
      topo_maskedPWF.Points = [0.007018464617431164, 0.0, 0.5, 0.0, 3428.5, 1.0, 0.5, 0.0]
      topo_maskedPWF.ScalarRangeInitialized = 1

      # ----------------------------------------------------------------
      # setup the visualization in view 'renderView1'
      # ----------------------------------------------------------------

      # show data from threshold1
      threshold1Display = Show(threshold1, renderView1)
      # trace defaults for the display properties.
      threshold1Display.Representation = 'Volume'
      threshold1Display.ColorArrayName = ['POINTS', 'qlev']
      threshold1Display.LookupTable = qlevLUT
      threshold1Display.OSPRayScaleArray = 'qlev'
      threshold1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      threshold1Display.SelectOrientationVectors = 'None'
      threshold1Display.ScaleFactor = 3.56160907745361
      threshold1Display.SelectScaleArray = 'None'
      threshold1Display.GlyphType = 'Arrow'
      threshold1Display.ScalarOpacityUnitDistance = 0.4
      threshold1Display.SelectMapper = 'Bunyk ray cast'
      threshold1Display.GaussianRadius = 1.78080453872681
      threshold1Display.SetScaleArray = ['POINTS', 'qlev']
      threshold1Display.ScaleTransferFunction = 'PiecewiseFunction'
      threshold1Display.OpacityArray = ['POINTS', 'qlev']
      threshold1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show color legend
      threshold1Display.SetScalarBarVisibility(renderView1, True)

      # show data from annotateGlobalData1
      annotateGlobalData1Display = Show(annotateGlobalData1, renderView1)
      # trace defaults for the display properties.
      annotateGlobalData1Display.FontSize = 8
      annotateGlobalData1Display.WindowLocation = 'AnyLocation'
      annotateGlobalData1Display.Position = [0.11863006846139695, 0.018211920529801348]

      # show data from warpByScalar1
      warpByScalar1Display = Show(warpByScalar1, renderView1)
      # trace defaults for the display properties.
      warpByScalar1Display.ColorArrayName = ['POINTS', 'topo_masked']
      warpByScalar1Display.LookupTable = topo_maskedLUT
      warpByScalar1Display.InterpolateScalarsBeforeMapping = 0
      warpByScalar1Display.OSPRayScaleArray = 'topo_masked'
      warpByScalar1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      warpByScalar1Display.SelectOrientationVectors = 'None'
      warpByScalar1Display.ScaleFactor = 3.4548349380493164
      warpByScalar1Display.SelectScaleArray = 'topo_masked'
      warpByScalar1Display.GlyphType = 'Arrow'
      warpByScalar1Display.ScalarOpacityUnitDistance = 1.258217374203218
      warpByScalar1Display.GaussianRadius = 1.7274174690246582
      warpByScalar1Display.SetScaleArray = ['POINTS', 'topo_masked']
      warpByScalar1Display.ScaleTransferFunction = 'PiecewiseFunction'
      warpByScalar1Display.OpacityArray = ['POINTS', 'topo_masked']
      warpByScalar1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show data from glyph1
      glyph1Display = Show(glyph1, renderView1)
      # trace defaults for the display properties.
      glyph1Display.ColorArrayName = ['POINTS', 'GlyphVector']
      glyph1Display.LookupTable = glyphVectorLUT
      glyph1Display.Opacity = 0.4
      glyph1Display.OSPRayScaleArray = 'topo_masked'
      glyph1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      glyph1Display.SelectOrientationVectors = 'GlyphVector'
      glyph1Display.ScaleFactor = 3.6937280654907227
      glyph1Display.SelectScaleArray = 'topo_masked'
      glyph1Display.GlyphType = 'Arrow'
      glyph1Display.GaussianRadius = 1.8468640327453614
      glyph1Display.SetScaleArray = ['POINTS', 'topo_masked']
      glyph1Display.ScaleTransferFunction = 'PiecewiseFunction'
      glyph1Display.OpacityArray = ['POINTS', 'topo_masked']
      glyph1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show color legend
      glyph1Display.SetScalarBarVisibility(renderView1, True)

      # setup the color legend parameters for each legend in this view

      # get color legend/bar for qlevLUT in view renderView1
      qlevLUTColorBar = GetScalarBar(qlevLUT, renderView1)
      qlevLUTColorBar.Position = [0.4622639179864949, 0.9160596026490065]
      qlevLUTColorBar.Position2 = [0.4300000000000008, 0.11999999999999955]
      qlevLUTColorBar.Orientation = 'Horizontal'
      qlevLUTColorBar.Title = 'Relative Humidity (0-1)'
      qlevLUTColorBar.ComponentTitle = ''
      qlevLUTColorBar.TitleBold = 1
      qlevLUTColorBar.TitleFontSize = 4
      qlevLUTColorBar.LabelBold = 1
      qlevLUTColorBar.LabelFontSize = 4
      qlevLUTColorBar.RangeLabelFormat = '%4.1f'
      qlevLUTColorBar.TextPosition = 'Ticks left/bottom, annotations right/top'
      qlevLUTColorBar.AspectRatio = 60.0

      # get color legend/bar for glyphVectorLUT in view renderView1
      glyphVectorLUTColorBar = GetScalarBar(glyphVectorLUT, renderView1)
      glyphVectorLUTColorBar.Position = [0.00841209173036786, 0.9196688741721852]
      glyphVectorLUTColorBar.Position2 = [0.4300000000000005, 0.12000000000000166]
      glyphVectorLUTColorBar.AutoOrient = 0
      glyphVectorLUTColorBar.Orientation = 'Horizontal'
      glyphVectorLUTColorBar.Title = 'Surface Wind'
      glyphVectorLUTColorBar.ComponentTitle = 'Magnitude'
      glyphVectorLUTColorBar.TitleBold = 1
      glyphVectorLUTColorBar.TitleFontSize = 4
      glyphVectorLUTColorBar.LabelBold = 1
      glyphVectorLUTColorBar.LabelFontSize = 4
      glyphVectorLUTColorBar.RangeLabelFormat = '%4.1f'
      glyphVectorLUTColorBar.TextPosition = 'Ticks left/bottom, annotations right/top'
      glyphVectorLUTColorBar.AspectRatio = 60.0

      # ----------------------------------------------------------------
      # finally, restore active source
      SetActiveSource(threshold1)
      # ----------------------------------------------------------------
    return Pipeline()

  class CoProcessor(coprocessing.CoProcessor):
    def CreatePipeline(self, datadescription):
      self.Pipeline = _CreatePipeline(self, datadescription)

  coprocessor = CoProcessor()
  # these are the frequencies at which the coprocessor updates.
  freqs = {'atm_input2d': [1, 1, 1, 1, 1, 1, 1], 'atm_input3d': [1, 1, 1, 1, 1, 1]}
  coprocessor.SetUpdateFrequencies(freqs)
  return coprocessor

#--------------------------------------------------------------
# Global variables that will hold the pipeline for each timestep
# Creating the CoProcessor object, doesn't actually create the ParaView pipeline.
# It will be automatically setup when coprocessor.UpdateProducers() is called the
# first time.
coprocessor = CreateCoProcessor()

#--------------------------------------------------------------
# Enable Live-Visualizaton with ParaView
coprocessor.EnableLiveVisualization(False, 1)


# ---------------------- Data Selection method ----------------------

def RequestDataDescription(datadescription):
    "Callback to populate the request for current timestep"
    global coprocessor
    if datadescription.GetForceOutput() == True:
        # We are just going to request all fields and meshes from the simulation
        # code/adaptor.
        for i in range(datadescription.GetNumberOfInputDescriptions()):
            datadescription.GetInputDescription(i).AllFieldsOn()
            datadescription.GetInputDescription(i).GenerateMeshOn()
        return

    # setup requests for all inputs based on the requirements of the
    # pipeline.
    coprocessor.LoadRequestedData(datadescription)

# ------------------------ Processing method ------------------------

def DoCoProcessing(datadescription):
    "Callback to do co-processing for current timestep"
    global coprocessor

    # Update the coprocessor by providing it the newly generated simulation data.
    # If the pipeline hasn't been setup yet, this will setup the pipeline.
    coprocessor.UpdateProducers(datadescription)

    # Write output data, if appropriate.
    coprocessor.WriteData(datadescription);

    # Write image capture (Last arg: rescale lookup table), if appropriate.
    coprocessor.WriteImages(datadescription, rescale_lookuptable=False)

    # Live Visualization, if enabled.
    coprocessor.DoLiveVisualization(datadescription, "localhost", 22222)
