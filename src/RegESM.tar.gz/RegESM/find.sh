#!/bin/bash

ldir=$1

lst=`ls -al $1/lib* | awk '{print $9}'`
for i in $lst
do
  str=`nm $i | grep "$2"`
  if [ -n "$str" ]; then
    echo $i
  fi
done
